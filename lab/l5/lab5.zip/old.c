#include "gui.h"

int main(int argc, char *argv[]) {
   return old(argc,argv);
}