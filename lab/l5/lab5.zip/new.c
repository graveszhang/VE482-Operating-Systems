#include "gui.h"

int main(int argc, char *argv[]) {
   return newmain(argc,argv);
}