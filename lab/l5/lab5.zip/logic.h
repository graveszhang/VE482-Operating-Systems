//
// Created by grave on 2020/10/26.
//

#ifndef L5_LOGIC_H
#define L5_LOGIC_H

#include "linkedlist.h"

const char *DATA_TYPES[3] = {"int.txt", "double.txt", "string.txt"};
const char *SORT_TYPES[3] = {"inc", "dec", "rand"};
void sort(int i, int j);

#endif // L5_LOGIC_H

