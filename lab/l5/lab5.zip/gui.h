//
// Created by grave on 2020/10/26.
//

#ifndef L5_GUI_H
#define L5_GUI_H

int newmain(int argc, char *argv[]);
int oldmain(int argc, char *argv[]);

#endif //L5_GUI_H